var searchData=
[
  ['yellow',['YELLOW',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55bae735a848bf82163a19236ead1c3ef2d2',1,'sgl::GColor']]]
];
