var searchData=
[
  ['load',['load',['../classGCanvas.html#a6c21edd9d285c925527e3209fca54b01',1,'GCanvas']]],
  ['loadcanvaspixels',['loadCanvasPixels',['../classGWindow.html#ae2462f15e288c06c5136e31a8ac8151c',1,'GWindow']]]
];
