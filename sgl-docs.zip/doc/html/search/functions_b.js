var searchData=
[
  ['load',['load',['../classsgl_1_1GCanvas.html#a6c21edd9d285c925527e3209fca54b01',1,'sgl::GCanvas']]],
  ['loadcanvaspixels',['loadCanvasPixels',['../classsgl_1_1GWindow.html#ae2462f15e288c06c5136e31a8ac8151c',1,'sgl::GWindow']]]
];
