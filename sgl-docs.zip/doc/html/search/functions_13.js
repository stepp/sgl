var searchData=
[
  ['valueisbool',['valueIsBool',['../classGTextField.html#a203f90275053ab957b1ea5a40dc3dd1e',1,'GTextField']]],
  ['valueischar',['valueIsChar',['../classGTextField.html#ac7a337b1e4c2f752a7f3fb634c92b442',1,'GTextField']]],
  ['valueisdouble',['valueIsDouble',['../classGTextField.html#aa80caadc7498333f74a08b4cdc0528c1',1,'GTextField']]],
  ['valueisint',['valueIsInt',['../classGTextField.html#a4bccf08b3b712af3839106a1cbdc5d02',1,'GTextField']]],
  ['valueisinteger',['valueIsInteger',['../classGTextField.html#af5aaf003739648d9aee89a17e715a57e',1,'GTextField']]],
  ['valueisreal',['valueIsReal',['../classGTextField.html#a29a5f540431d7993ff00eee5d2584a36',1,'GTextField']]]
];
