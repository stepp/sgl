var searchData=
[
  ['width',['width',['../structsgl_1_1GDimension.html#a9df23e056f5d1a0388cd8190431c0e03',1,'sgl::GDimension::width()'],['../structsgl_1_1GRectangle.html#a9df23e056f5d1a0388cd8190431c0e03',1,'sgl::GRectangle::width()']]],
  ['width_5fheight_5fmax',['WIDTH_HEIGHT_MAX',['../classsgl_1_1GCanvas.html#a9150dbfb90e715487461a8c07850871e',1,'sgl::GCanvas']]]
];
