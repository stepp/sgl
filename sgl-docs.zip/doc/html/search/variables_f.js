var searchData=
[
  ['y',['y',['../structGPoint.html#ab927965981178aa1fba979a37168db2a',1,'GPoint::y()'],['../structGRectangle.html#ab927965981178aa1fba979a37168db2a',1,'GRectangle::y()']]]
];
