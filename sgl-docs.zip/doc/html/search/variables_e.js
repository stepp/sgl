var searchData=
[
  ['x',['x',['../structGPoint.html#af88b946fb90d5f08b5fb740c70e98c10',1,'GPoint::x()'],['../structGRectangle.html#af88b946fb90d5f08b5fb740c70e98c10',1,'GRectangle::x()']]]
];
