var searchData=
[
  ['closeoperation',['CloseOperation',['../classsgl_1_1GWindow.html#a84803201f0f9569db61f51cac9e0d2d2',1,'sgl::GWindow']]],
  ['columnheaderstyle',['ColumnHeaderStyle',['../classsgl_1_1GTable.html#a060cff504451bbb98530e64e936e2671',1,'sgl::GTable']]],
  ['confirmresult',['ConfirmResult',['../classsgl_1_1GOptionPane.html#a1cc9e8685029e39646671ed71f32d47d',1,'sgl::GOptionPane']]],
  ['confirmtype',['ConfirmType',['../classsgl_1_1GOptionPane.html#a6a1aaf19c06f5a6bef89ea6415547049',1,'sgl::GOptionPane']]]
];
