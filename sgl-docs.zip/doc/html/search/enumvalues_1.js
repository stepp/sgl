var searchData=
[
  ['backspace_5fkey',['BACKSPACE_KEY',['../classGEvent.html#a7885f47644a0388f981f416fa20389b2a4dd1e53528965cb26b7ef9dc9cca8485',1,'GEvent']]],
  ['black',['BLACK',['../classGColor.html#a06fc87d81c62e9abb8790b6e5713c55baf77fb67151d0c18d397069ad8c271ba3',1,'GColor']]],
  ['blue',['BLUE',['../classGColor.html#a06fc87d81c62e9abb8790b6e5713c55ba35d6719cb4d7577c031b3d79057a1b79',1,'GColor']]],
  ['brown',['BROWN',['../classGColor.html#a06fc87d81c62e9abb8790b6e5713c55ba1fa14482e7e4dc1332ab8c9d995fe570',1,'GColor']]]
];
