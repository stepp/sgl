var searchData=
[
  ['backspace_5fkey',['BACKSPACE_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2a4dd1e53528965cb26b7ef9dc9cca8485',1,'sgl::GEvent']]],
  ['black',['BLACK',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55baf77fb67151d0c18d397069ad8c271ba3',1,'sgl::GColor']]],
  ['blue',['BLUE',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55ba35d6719cb4d7577c031b3d79057a1b79',1,'sgl::GColor']]],
  ['boldfont',['boldFont',['../classsgl_1_1GFont.html#ae709c4560c613217490269d4df94602c',1,'sgl::GFont']]],
  ['brown',['BROWN',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55ba1fa14482e7e4dc1332ab8c9d995fe570',1,'sgl::GColor']]],
  ['button1_5fdown',['BUTTON1_DOWN',['../namespacesgl.html#a80f90997871cd543ddb0bf8d282becdda8253fc24be9aeea3fee38cd469f62b6e',1,'sgl']]],
  ['button2_5fdown',['BUTTON2_DOWN',['../namespacesgl.html#a80f90997871cd543ddb0bf8d282becddaf46ada1f33b75879c7187479eff8d63a',1,'sgl']]],
  ['button3_5fdown',['BUTTON3_DOWN',['../namespacesgl.html#a80f90997871cd543ddb0bf8d282becdda898da527b65805df9eb0cc316cb01d19',1,'sgl']]]
];
