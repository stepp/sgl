var searchData=
[
  ['page_5fdown_5fkey',['PAGE_DOWN_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2acaabcca133206248fbe0be4447dce25c',1,'sgl::GEvent']]],
  ['page_5fup_5fkey',['PAGE_UP_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2a303b1e3e75da2aebf9cbaf4dfa833d5e',1,'sgl::GEvent']]],
  ['pause_5fkey',['PAUSE_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2a6a27d19c37941821112decd8a2c301d6',1,'sgl::GEvent']]],
  ['pink',['PINK',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55ba186598537092d140eaa60720ec7e0821',1,'sgl::GColor']]],
  ['print_5fscreen_5fkey',['PRINT_SCREEN_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2a7770443994203f243868d62da29e3ceb',1,'sgl::GEvent']]],
  ['purple',['PURPLE',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55ba2772ad7cd64f03c2aed60f91c69fa69d',1,'sgl::GColor']]]
];
