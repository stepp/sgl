var searchData=
[
  ['eventclass',['EventClass',['../namespacesgl.html#a6ff6e8ee75a08092e30167b2b7c5d6f7',1,'sgl']]],
  ['eventtype',['EventType',['../namespacesgl.html#a2628ea8d12e8b2563c32f05dc7fff6fa',1,'sgl']]]
];
