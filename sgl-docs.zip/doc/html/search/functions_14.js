var searchData=
[
  ['valueisbool',['valueIsBool',['../classsgl_1_1GTextField.html#a203f90275053ab957b1ea5a40dc3dd1e',1,'sgl::GTextField']]],
  ['valueischar',['valueIsChar',['../classsgl_1_1GTextField.html#ac7a337b1e4c2f752a7f3fb634c92b442',1,'sgl::GTextField']]],
  ['valueisdouble',['valueIsDouble',['../classsgl_1_1GTextField.html#aa80caadc7498333f74a08b4cdc0528c1',1,'sgl::GTextField']]],
  ['valueisint',['valueIsInt',['../classsgl_1_1GTextField.html#a4bccf08b3b712af3839106a1cbdc5d02',1,'sgl::GTextField']]],
  ['valueisinteger',['valueIsInteger',['../classsgl_1_1GTextField.html#af5aaf003739648d9aee89a17e715a57e',1,'sgl::GTextField']]],
  ['valueisreal',['valueIsReal',['../classsgl_1_1GTextField.html#a29a5f540431d7993ff00eee5d2584a36',1,'sgl::GTextField']]],
  ['vectorangle',['vectorAngle',['../namespacesgl_1_1math.html#a51453f572f4bc800c79c499d129c8c0d',1,'sgl::math::vectorAngle(double x, double y)'],['../namespacesgl_1_1math.html#a2d623f59e6cb1d14a223c443403d568f',1,'sgl::math::vectorAngle(const ::sgl::GPoint &amp;pt)']]],
  ['vectordistance',['vectorDistance',['../namespacesgl_1_1math.html#a3bb5a1a1bfbde21be9ed3ae002133143',1,'sgl::math::vectorDistance(double x, double y)'],['../namespacesgl_1_1math.html#a250e1f2b1892e792842af09e46670b84',1,'sgl::math::vectorDistance(const ::sgl::GPoint &amp;pt)']]]
];
