var searchData=
[
  ['width',['width',['../structGDimension.html#a9df23e056f5d1a0388cd8190431c0e03',1,'GDimension::width()'],['../structGRectangle.html#a9df23e056f5d1a0388cd8190431c0e03',1,'GRectangle::width()']]],
  ['width_5fheight_5fmax',['WIDTH_HEIGHT_MAX',['../classGCanvas.html#a9150dbfb90e715487461a8c07850871e',1,'GCanvas']]]
];
