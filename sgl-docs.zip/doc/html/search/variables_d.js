var searchData=
[
  ['y',['y',['../structsgl_1_1GPoint.html#ab927965981178aa1fba979a37168db2a',1,'sgl::GPoint::y()'],['../structsgl_1_1GRectangle.html#ab927965981178aa1fba979a37168db2a',1,'sgl::GRectangle::y()']]]
];
