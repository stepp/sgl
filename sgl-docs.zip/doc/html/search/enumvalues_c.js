var searchData=
[
  ['null_5fevent',['NULL_EVENT',['../namespacesgl.html#a6ff6e8ee75a08092e30167b2b7c5d6f7ad986036666e3b6f3a053e2b1f43c1495',1,'sgl']]],
  ['null_5ftype',['NULL_TYPE',['../namespacesgl.html#a2628ea8d12e8b2563c32f05dc7fff6faa74cf8825b522b9721ea02973803d76b4',1,'sgl']]],
  ['num_5flock_5fkey',['NUM_LOCK_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2ae1026f2a198d4e7aa63043b67818d9ea',1,'sgl::GEvent']]]
];
