var searchData=
[
  ['orientation',['Orientation',['../classGScrollBar.html#a871118a09520247c78a71ecd7b0abd58',1,'GScrollBar::Orientation()'],['../classGSlider.html#a871118a09520247c78a71ecd7b0abd58',1,'GSlider::Orientation()']]]
];
