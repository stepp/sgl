var searchData=
[
  ['messagetype',['MessageType',['../classsgl_1_1GOptionPane.html#ac6606ebe91c8ac66a2c314c79f5ab013',1,'sgl::GOptionPane']]],
  ['modifier',['Modifier',['../namespacesgl.html#a80f90997871cd543ddb0bf8d282becdd',1,'sgl']]]
];
