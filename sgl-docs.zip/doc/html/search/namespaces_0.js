var searchData=
[
  ['diff',['diff',['../namespacediff.html',1,'']]]
];
