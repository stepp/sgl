var searchData=
[
  ['require',['require',['../namespacerequire.html',1,'']]]
];
