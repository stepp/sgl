var searchData=
[
  ['height',['height',['../structGDimension.html#a89f6abd564014faeff7cd20c340a9c7d',1,'GDimension::height()'],['../structGRectangle.html#a89f6abd564014faeff7cd20c340a9c7d',1,'GRectangle::height()']]],
  ['high_5fdpi_5fscreen_5fthreshold',['HIGH_DPI_SCREEN_THRESHOLD',['../classGWindow.html#a212e92d31b813ef25adbb902ffae3c6b',1,'GWindow']]]
];
