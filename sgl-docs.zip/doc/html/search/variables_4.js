var searchData=
[
  ['height',['height',['../structsgl_1_1GDimension.html#a89f6abd564014faeff7cd20c340a9c7d',1,'sgl::GDimension::height()'],['../structsgl_1_1GRectangle.html#a89f6abd564014faeff7cd20c340a9c7d',1,'sgl::GRectangle::height()']]],
  ['high_5fdpi_5fscreen_5fthreshold',['HIGH_DPI_SCREEN_THRESHOLD',['../classsgl_1_1GWindow.html#a212e92d31b813ef25adbb902ffae3c6b',1,'sgl::GWindow']]]
];
