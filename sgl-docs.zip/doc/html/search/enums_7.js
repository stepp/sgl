var searchData=
[
  ['region',['Region',['../classGContainer.html#a81a01a86de31071a92e6cce0bab9bc4b',1,'GContainer::Region()'],['../classGWindow.html#a81a01a86de31071a92e6cce0bab9bc4b',1,'GWindow::Region()']]]
];
