var searchData=
[
  ['orientation',['Orientation',['../classsgl_1_1GScrollBar.html#a871118a09520247c78a71ecd7b0abd58',1,'sgl::GScrollBar::Orientation()'],['../classsgl_1_1GSlider.html#a871118a09520247c78a71ecd7b0abd58',1,'sgl::GSlider::Orientation()']]]
];
