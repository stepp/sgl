var searchData=
[
  ['verticalalignment',['VerticalAlignment',['../namespacesgl.html#a9c2ed22cfbd21f13df24ea193b310aee',1,'sgl']]]
];
