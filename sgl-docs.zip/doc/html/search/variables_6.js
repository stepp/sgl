var searchData=
[
  ['margin_5fdefault',['MARGIN_DEFAULT',['../classsgl_1_1GContainer.html#a9fbdb565727493808a950b2bdfa72145',1,'sgl::GContainer']]]
];
