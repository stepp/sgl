var searchData=
[
  ['spacing_5fdefault',['SPACING_DEFAULT',['../classsgl_1_1GContainer.html#a2f9f03af35bbe9cd402d12efb4caa4a3',1,'sgl::GContainer']]],
  ['standard_5fscreen_5fdpi',['STANDARD_SCREEN_DPI',['../classsgl_1_1GWindow.html#a28d634f1a144a0f1aabf338f0be6afe2',1,'sgl::GWindow']]]
];
