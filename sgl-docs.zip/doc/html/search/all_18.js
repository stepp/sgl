var searchData=
[
  ['x',['x',['../structsgl_1_1GPoint.html#af88b946fb90d5f08b5fb740c70e98c10',1,'sgl::GPoint::x()'],['../structsgl_1_1GRectangle.html#af88b946fb90d5f08b5fb740c70e98c10',1,'sgl::GRectangle::x()']]]
];
