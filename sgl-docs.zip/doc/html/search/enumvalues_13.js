var searchData=
[
  ['vertical',['VERTICAL',['../classsgl_1_1GScrollBar.html#a871118a09520247c78a71ecd7b0abd58a1a88641fcd39f2ed3e58a18526e97138',1,'sgl::GScrollBar::VERTICAL()'],['../classsgl_1_1GSlider.html#a871118a09520247c78a71ecd7b0abd58a1a88641fcd39f2ed3e58a18526e97138',1,'sgl::GSlider::VERTICAL()']]]
];
