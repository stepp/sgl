var searchData=
[
  ['white',['WHITE',['../classGColor.html#a06fc87d81c62e9abb8790b6e5713c55ba283fc479650da98250635b9c3c0e7e50',1,'GColor']]],
  ['windows_5fkey',['WINDOWS_KEY',['../classGEvent.html#a7885f47644a0388f981f416fa20389b2aaf4f7c51ea158581a9bc455e9a12a649',1,'GEvent']]]
];
