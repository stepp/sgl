var searchData=
[
  ['horizontalalignment',['HorizontalAlignment',['../namespacesgl.html#aa00e70829e72ff16addc4d9f06fe3bc5',1,'sgl']]]
];
