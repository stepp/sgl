var searchData=
[
  ['col',['col',['../structsgl_1_1GTableIndex.html#afb52e720f5f0c483db5861f9e42e924e',1,'sgl::GTableIndex']]],
  ['color',['Color',['../classsgl_1_1GColor.html#ade7509ad941851393fbb7394bc048f82',1,'sgl::GColor']]]
];
