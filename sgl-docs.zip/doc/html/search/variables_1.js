var searchData=
[
  ['color',['Color',['../classGColor.html#a829e668b6af432af22e4fe68feff8c9a',1,'GColor']]]
];
