var searchData=
[
  ['forwardingstreambuf',['ForwardingStreambuf',['../classsgl_1_1ForwardingStreambuf.html',1,'sgl']]]
];
