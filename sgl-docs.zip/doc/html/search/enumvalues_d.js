var searchData=
[
  ['orange',['ORANGE',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55bace9ee4c1a6b777940c7f3a766a9a88d4',1,'sgl::GColor']]]
];
