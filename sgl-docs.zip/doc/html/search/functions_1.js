var searchData=
[
  ['boldfont',['boldFont',['../classsgl_1_1GFont.html#ae709c4560c613217490269d4df94602c',1,'sgl::GFont']]]
];
