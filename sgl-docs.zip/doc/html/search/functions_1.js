var searchData=
[
  ['boldfont',['boldFont',['../classGFont.html#ae709c4560c613217490269d4df94602c',1,'GFont']]]
];
