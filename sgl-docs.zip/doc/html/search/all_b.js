var searchData=
[
  ['key_5fevent',['KEY_EVENT',['../namespacesgl.html#a6ff6e8ee75a08092e30167b2b7c5d6f7a0e6d8d51cdea5a4ed106568ba7637ad2',1,'sgl']]],
  ['key_5fpressed',['KEY_PRESSED',['../namespacesgl.html#a2628ea8d12e8b2563c32f05dc7fff6faac2439afec39a5b43a1fd36a4316379a7',1,'sgl']]],
  ['key_5freleased',['KEY_RELEASED',['../namespacesgl.html#a2628ea8d12e8b2563c32f05dc7fff6faa207f5f32e6d172c4003ec10fab0cb06d',1,'sgl']]],
  ['key_5ftyped',['KEY_TYPED',['../namespacesgl.html#a2628ea8d12e8b2563c32f05dc7fff6faae573ac60eeeb71fe98146f2dc970529a',1,'sgl']]],
  ['keycode',['KeyCode',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2',1,'sgl::GEvent']]],
  ['keycodetostring',['keyCodeToString',['../classsgl_1_1GEvent.html#a6e882459d29785fb753a3bf23f29cbc3',1,'sgl::GEvent']]]
];
