var searchData=
[
  ['no_5fdiffs_5fmessage',['NO_DIFFS_MESSAGE',['../namespacediff.html#a4f8bdb0eae6c54a481aba9358db1e9ab',1,'diff']]]
];
