var searchData=
[
  ['platform',['platform',['../namespaceplatform.html',1,'']]]
];
