var searchData=
[
  ['inputtype',['InputType',['../classsgl_1_1GTextField.html#a5fc772c800c3d40d2b95564e8a839bab',1,'sgl::GTextField']]]
];
