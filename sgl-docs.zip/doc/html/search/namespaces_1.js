var searchData=
[
  ['gexceptions',['gexceptions',['../namespacegexceptions.html',1,'']]]
];
