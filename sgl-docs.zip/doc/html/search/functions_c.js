var searchData=
[
  ['maximize',['maximize',['../classsgl_1_1GWindow.html#a1aa481996525792213f28d91fbb4894b',1,'sgl::GWindow']]],
  ['minimize',['minimize',['../classsgl_1_1GWindow.html#a85ffaebe489c0ecf8051715ecf59babb',1,'sgl::GWindow']]],
  ['move',['move',['../classsgl_1_1GObject.html#a5973d8dda83afb36e2c56855515be392',1,'sgl::GObject']]],
  ['movecursortoend',['moveCursorToEnd',['../classsgl_1_1GBrowserPane.html#ab5ef729cac166db0ef51ff7ea30d1bb8',1,'sgl::GBrowserPane::moveCursorToEnd()'],['../classsgl_1_1GTextArea.html#ab5ef729cac166db0ef51ff7ea30d1bb8',1,'sgl::GTextArea::moveCursorToEnd()']]],
  ['movecursortostart',['moveCursorToStart',['../classsgl_1_1GBrowserPane.html#a24abdceab57bcff96185afbadf193a22',1,'sgl::GBrowserPane::moveCursorToStart()'],['../classsgl_1_1GTextArea.html#a24abdceab57bcff96185afbadf193a22',1,'sgl::GTextArea::moveCursorToStart()']]]
];
