var searchData=
[
  ['gray',['GRAY',['../classGColor.html#a06fc87d81c62e9abb8790b6e5713c55ba3fb6c4ad00f4ad98553e01229d1803ac',1,'GColor']]],
  ['green',['GREEN',['../classGColor.html#a06fc87d81c62e9abb8790b6e5713c55baa60bd322f93178d68184e30e162571ca',1,'GColor']]]
];
