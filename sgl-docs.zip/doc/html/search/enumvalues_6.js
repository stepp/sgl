var searchData=
[
  ['gray',['GRAY',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55ba3fb6c4ad00f4ad98553e01229d1803ac',1,'sgl::GColor']]],
  ['green',['GREEN',['../classsgl_1_1GColor.html#a06fc87d81c62e9abb8790b6e5713c55baa60bd322f93178d68184e30e162571ca',1,'sgl::GColor']]]
];
