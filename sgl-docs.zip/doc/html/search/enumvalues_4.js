var searchData=
[
  ['end_5fkey',['END_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2aad81a36193ad805db56f8d06c6210d2c',1,'sgl::GEvent']]],
  ['enter_5fkey',['ENTER_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2a3e386e3874767e9b60555335164772ff',1,'sgl::GEvent']]],
  ['escape_5fkey',['ESCAPE_KEY',['../classsgl_1_1GEvent.html#a7885f47644a0388f981f416fa20389b2ad710e81a592eb9cdec0c237c1efdc027',1,'sgl::GEvent']]]
];
