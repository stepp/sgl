var searchData=
[
  ['layout',['Layout',['../classsgl_1_1GContainer.html#a1b7da28ed84c0763e8f92cde2df4799b',1,'sgl::GContainer']]],
  ['linestyle',['LineStyle',['../classsgl_1_1GObject.html#a86e0f5648542856159bb40775c854aa7',1,'sgl::GObject']]]
];
