var searchData=
[
  ['scrollbarpolicy',['ScrollBarPolicy',['../classGScrollPane.html#af276320d3d533d494547cb40e5025cc9',1,'GScrollPane']]],
  ['status_5ft',['status_t',['../namespacegexceptions.html#af9bff8ff1154a04a899276af806b8586',1,'gexceptions']]]
];
