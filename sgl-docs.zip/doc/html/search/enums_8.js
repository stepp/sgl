var searchData=
[
  ['region',['Region',['../classsgl_1_1GContainer.html#a81a01a86de31071a92e6cce0bab9bc4b',1,'sgl::GContainer::Region()'],['../classsgl_1_1GWindow.html#a81a01a86de31071a92e6cce0bab9bc4b',1,'sgl::GWindow::Region()']]]
];
